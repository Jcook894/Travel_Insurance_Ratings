<?php
/**
* @version $Id: admin.reviews_init.php 4905 2009-02-18 17:14:45Z Sigrid Suski $
* @package: Sigsiu Online Business Index 2
* ===================================================
* @author
* Name: Sigrid & Radek Suski, Sigsiu.NET
* Email: sobi@sigsiu.net
* Url: http://www.sigsiu.net
* ===================================================
* @copyright Copyright (C) 2007 Sigsiu.NET (http://www.sigsiu.net). All rights reserved.
* @license see http://www.gnu.org/copyleft/gpl.html GNU/GPL.
* SOBI2 is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation.
*/
	defined( '_SOBI2_' ) || ( trigger_error("Restricted access", E_USER_ERROR) && exit() );
	if(defined("_SOBI_ADM_PATH")) {
		$config =& adminConfig::getInstance();
		sobi2Config::import("plugins|reviews|admin.reviews.class", "adm");
		if(!sobi2Config::import("plugins|reviews|{$config->sobi2Language}", "front", false, false)) {
			sobi2Config::import("plugins|reviews|english", "front", true, false);		
		}
		/*
		 * create an object
		 */
		$sobi_reviews_adm = new sobi_reviews_adm();
		/*
		 * put the object to the plugins array
		 * $plugin->name is definied in sobi2.php
		 */
		$config->S2_plugins[$plugin->name_id] = $sobi_reviews_adm;
	}
	else {
		if(sobi2Config::request($_REQUEST, "task", null) != "pluginsManager") {
			$url = "index2.php?option=com_sobi2&task=pluginsManager&mosmsg=".urlencode("The Reviews and Ratings plugin requires at least SOBI2 RC 2.8.0. Please uninstall this plugin and update your SOBI2 version");
			echo "<script>document.location.href='{$url}';</script>\n";
		}
	}
?>
