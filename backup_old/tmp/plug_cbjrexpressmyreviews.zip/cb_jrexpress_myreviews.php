<?php
/*
    JReviews Express - user reviews for Joomla
    Copyright (C) 2009  Alejandro Schmeichler

    JReviews Express is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    JReviews Express is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

(defined( '_VALID_MOS') || defined( '_JEXEC')) or die( 'Direct Access to this location is not allowed.' );


class cb_jrexpress_myreviews extends cbTabHandler {
	var $catid = null;
	var $criteriaid = null;
	var $option = 'com_comprofiler';

	function cb_jrexpress_myreviews() {

//		$this->cbTabHandler();

	}

	/**
	* Generates the menu and user status to display on the user profile by calling back $this->addMenu
	*/
	function getMenuAndStatus($tab,$user,$ui) {
		return true;
	}

	/**
	* Generates the HTML to display the user profile tab
	*/
	function getDisplayTab($tab,$user,$ui) {

		global $my;

		$userId = isset($_REQUEST['user']) ? (int) $_REQUEST['user'] : $user->id;
				
		$params = $this->params;		

		// Check access setting
		if($params->get('access') && $userId != $my->id) {
			return null;	
		}
		
		# MVC initalization script
		if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);	
		require('components' . DS . 'com_jrexpress' . DS . 'jrexpress' . DS . 'framework.php');
				           
		# Populate $params array with module settings
		$eParams['page'] = 1;
		$eParams['user'] = $userId;		
		$eParams['module'] = stringToArray($params->_raw);		
		$eParams['module']['community'] = true;
		$eParams['module_id'] = 'plugin_myreviews'.$userId;
		$eParams['page'] = 1;
		$eParams['data']['module'] = true;		
		
		$eParams['data']['controller'] = 'community_reviews';		
		$eParams['data']['action'] = 'index';
		$eParams['data']['module_limit'] = $params->get('limit',10);		
		
		$Dispatcher = new S2Dispatcher('jrexpress',true, true);
		return $Dispatcher->dispatch($eParams);		

	} // end or getDisplayTab function

}
?>